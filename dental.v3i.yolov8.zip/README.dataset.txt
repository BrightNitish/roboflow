# dental > 2025-07-13 11:53pm
https://universe.roboflow.com/dentaldata-vzyni/dental-nblac

Provided by a Roboflow user
License: CC BY 4.0

